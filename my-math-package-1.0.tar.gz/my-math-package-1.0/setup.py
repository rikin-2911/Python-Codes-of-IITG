from setuptools import setup, find_packages
setup(
    name = 'my-math-package',
    version = '1.0',
    author = 'Rikin Pithadia',
    description = 'A package with basic math and geometry functions',
    packages = find_packages(),
)

